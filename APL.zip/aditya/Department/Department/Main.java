import department.Faculty.Faculty;
import department.Student.Student;
import department.Course.Course;

public class Main {
    public static void main(String[] args) {
        Course course1 = new Course("AI");
        Course course2 = new Course("Physics");
        Course course3 = new Course("Maths");
        Course course4 = new Course("SPM");
        Course course5 = new Course("WT");

        Faculty f1 = new Faculty("Dr. Hadimani Sir");
        Faculty f2 = new Faculty("Dr. Desai Sir");
        Faculty f3 = new Faculty("Dr. Patil Sir");
        Faculty f4 = new Faculty("Dr. Powar Sir");
        Faculty f5 = new Faculty("Dr. Kapase Sir");

        f1.assignCourse(course1);
        f2.assignCourse(course2);
        f3.assignCourse(course3);
        f4.assignCourse(course4);
        f5.assignCourse(course5);

        Student[] students = new Student[50];
        for (int i = 0; i < students.length; i++) {
            students[i] = new Student("Student" + (i + 1));
        }

        for (int i = 0; i < 50; i++) {
            if (i < 10) {
                students[i].assignCourse(course1);
                f1.assignMentee(students[i]);
            } else if (i < 20) {
                students[i].assignCourse(course2);
                f2.assignMentee(students[i]);
            } else if (i < 30) {
                students[i].assignCourse(course3);
                f3.assignMentee(students[i]);
            } else if (i < 40) {
                students[i].assignCourse(course4);
                f4.assignMentee(students[i]);
            } else {
                students[i].assignCourse(course5);
                f5.assignMentee(students[i]);
            }
        }

        f1.displayMentees();
        System.out.println();
        f2.displayMentees();
        System.out.println();
        f3.displayMentees();
        System.out.println();
        f4.displayMentees();
        System.out.println();
        f5.displayMentees();
        System.out.println();
    }
}
