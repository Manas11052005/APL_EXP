package department.Course;

import department.Faculty.Faculty;

public class Course {
    private String name;
    private Faculty faculty;

    public Course(String name) {
        this.name = name;
    }

    public void assignFaculty(Faculty faculty) {
        this.faculty = faculty;
    }

    public String getName() {
        return name;
    }
}
