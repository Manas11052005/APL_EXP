package department.Faculty;

import department.Student.Student;
import department.Course.Course;
import java.util.*;

public class Faculty {
    private String name;
    private List<Student> mentees;
    private Course course;

    public Faculty(String name) {
        this.name = name;
        this.mentees = new ArrayList<>();
    }

    public void assignMentee(Student student) {
        mentees.add(student);
    }

    public void assignCourse(Course course) {
        this.course = course;
        course.assignFaculty(this);
    }

    public void displayMentees() {
        System.out.println("Faculty: " + name);
        System.out.println("Mentees:");
        for (Student s : mentees) {
            System.out.println(" - " + s.getName());
        }
    }

    public String getName() {
        return name;
    }
}