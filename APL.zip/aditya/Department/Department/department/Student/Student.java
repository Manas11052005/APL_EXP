package department.Student;

import department.Course.Course;

public class Student {
    private String name;
    private Course course;

    public Student(String name) {
        this.name = name;
    }

    public void assignCourse(Course course) {
        this.course = course;
    }

    public String getName() {
        return name;
    }
}
