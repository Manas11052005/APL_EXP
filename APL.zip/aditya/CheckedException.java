// Custom exception class
class InsufficientException extends RuntimeException {
    int currentBalance;

    InsufficientException(int balance) {
        this.currentBalance = balance;
    }

    public String toString() {
        return "Insufficient Balance. Available: " + currentBalance;
    }
}

// BankAccount class
class BankAccount {
    int balance = 10000;

    void deposit(int amount) {
        balance += amount;
        System.out.println("Deposited: " + amount);
    }

    void withdraw(int amount) throws InsufficientException {
        if (amount > balance) {
            throw new InsufficientException(balance);
        }
        balance -= amount;
        System.out.println("Withdrawn: " + amount);
    }

    int getBalance() {
        return balance;
    }

    public static void main(String[] args) {
        BankAccount account = new BankAccount();

        try {
            account.deposit(10000);      // Balance becomes 20000
            account.withdraw(5000);      // Withdraws successfully
            // Uncomment below to test exception:
            // account.withdraw(30000);  // Will throw exception
        } catch (InsufficientException e) {
            System.out.println(e);       // Print error message
        }

        System.out.println("Final Balance: " + account.getBalance());
    }
}
