import java.io.*;
import java.util.*;

public class EmployeeManagementSystemApp {
    // --- Serializable Employee class ---
    static class Employee implements Serializable {
        private int id;
        private String name;
        private String department;
        private double salary;

        public Employee(int id, String name, String department, double salary) {
            this.id = id;
            this.name = name;
            this.department = department;
            this.salary = salary;
        }

        public int getId() { return id; }
        public String getName() { return name; }
        public String getDepartment() { return department; }
        public double getSalary() { return salary; }

        public void setId(int id) { this.id = id; }
        public void setName(String name) { this.name = name; }
        public void setDepartment(String department) { this.department = department; }
        public void setSalary(double salary) { this.salary = salary; }

        @Override
        public String toString() {
            return String.format("ID: %d, Name: %s, Department: %s, Salary: %.2f",
                    id, name, department, salary);
        }
    }

    // --- Main System Class ---
    static class EmployeeManagementSystem {
        private static final String FILE_NAME = "employees.dat";

        // Read employee list from file
        private List<Employee> readEmployees() {
            List<Employee> employees = new ArrayList<>();
            try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
                employees = (List<Employee>) ois.readObject();
            } catch (FileNotFoundException e) {
                // file may not exist initially
            } catch (Exception e) {
                e.printStackTrace();
            }
            return employees;
        }

        // Write employee list to file
        private void writeEmployees(List<Employee> employees) {
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
                oos.writeObject(employees);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void addEmployee(Employee emp) {
            List<Employee> employees = readEmployees();
            employees.add(emp);
            writeEmployees(employees);
            System.out.println("Employee added successfully.");
        }

        public void viewEmployees() {
            List<Employee> employees = readEmployees();
            if (employees.isEmpty()) {
                System.out.println("No employee records found.");
                return;
            }
            System.out.printf("%-5s %-15s %-15s %-10s\n", "ID", "Name", "Department", "Salary");
            System.out.println("------------------------------------------------------");
            for (Employee emp : employees) {
                System.out.printf("%-5d %-15s %-15s %-10.2f\n", emp.getId(), emp.getName(), emp.getDepartment(), emp.getSalary());
            }
        }

        public void searchEmployeeById(int id) {
            List<Employee> employees = readEmployees();
            for (Employee emp : employees) {
                if (emp.getId() == id) {
                    System.out.println("Employee Found: " + emp);
                    return;
                }
            }
            System.out.println("Employee with ID " + id + " not found.");
        }

        public void updateEmployee(int id, Employee updatedEmp) {
            List<Employee> employees = readEmployees();
            boolean updated = false;
            for (int i = 0; i < employees.size(); i++) {
                if (employees.get(i).getId() == id) {
                    employees.set(i, updatedEmp);
                    updated = true;
                    break;
                }
            }
            if (updated) {
                writeEmployees(employees);
                System.out.println("Employee updated successfully.");
            } else {
                System.out.println("Employee with ID " + id + " not found.");
            }
        }

        public void deleteEmployee(int id) {
            List<Employee> employees = readEmployees();
            boolean removed = employees.removeIf(emp -> emp.getId() == id);
            if (removed) {
                writeEmployees(employees);
                System.out.println("Employee deleted successfully.");
            } else {
                System.out.println("Employee with ID " + id + " not found.");
            }
        }
    }

    // --- Main method for user interaction ---
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EmployeeManagementSystem ems = new EmployeeManagementSystem();
        int choice;

        do {
            System.out.println("\n--- Employee Management System (Serialized) ---");
            System.out.println("1. Add Employee");
            System.out.println("2. View Employees");
            System.out.println("3. Search Employee by ID");
            System.out.println("4. Update Employee");
            System.out.println("5. Delete Employee");
            System.out.println("0. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter ID: ");
                    int id = sc.nextInt();
                    sc.nextLine(); // consume newline
                    System.out.print("Enter Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Department: ");
                    String dept = sc.nextLine();
                    System.out.print("Enter Salary: ");
                    double sal = sc.nextDouble();
                    ems.addEmployee(new Employee(id, name, dept, sal));
                    break;

                case 2:
                    ems.viewEmployees();
                    break;

                case 3:
                    System.out.print("Enter ID to search: ");
                    int sid = sc.nextInt();
                    ems.searchEmployeeById(sid);
                    break;

                case 4:
                    System.out.print("Enter ID to update: ");
                    int uid = sc.nextInt();
                    sc.nextLine(); // consume newline
                    System.out.print("Enter new Name: ");
                    String uname = sc.nextLine();
                    System.out.print("Enter new Department: ");
                    String udept = sc.nextLine();
                    System.out.print("Enter new Salary: ");
                    double usal = sc.nextDouble();
                    ems.updateEmployee(uid, new Employee(uid, uname, udept, usal));
                    break;

                case 5:
                    System.out.print("Enter ID to delete: ");
                    int did = sc.nextInt();
                    ems.deleteEmployee(did);
                    break;

                case 0:
                    System.out.println("Exiting system. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 0);

        sc.close();
    }
}
