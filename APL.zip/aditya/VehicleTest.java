interface Vehicle {
    void start();
    void stop();
    int getSpeed();
    void setSpeed(int speed);
}

interface FuelPowered extends Vehicle {
    void refuel(int amount);
    int getFuelLevel();
}

class Car implements FuelPowered {
    int speed = 0;
    int fuel = 100;

    public void start() {
        System.out.println("Car started");
    }

    public void stop() {
        System.out.println("Car stopped");
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
        System.out.println("Car speed: " + speed);
    }

    public void refuel(int amount) {
        fuel += amount;
        System.out.println("Car refueled: +" + amount);
    }

    public int getFuelLevel() {
        return fuel;
    }
}

class Bike implements FuelPowered {
    int speed = 0;
    int fuel = 80;

    public void start() {
        System.out.println("Bike started");
    }

    public void stop() {
        System.out.println("Bike stopped");
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
        System.out.println("Bike speed: " + speed);
    }

    public void refuel(int amount) {
        fuel += amount;
        System.out.println("Bike refueled: +" + amount);
    }

    public int getFuelLevel() {
        return fuel;
    }
}

public class VehicleTest {
    public static void main(String[] args) {
        FuelPowered[] vehicles = { new Car(), new Bike() };

        for (FuelPowered vehicle : vehicles) {
            vehicle.start();
            vehicle.setSpeed(50);
            vehicle.refuel(20);
            System.out.println("Fuel Level: " + vehicle.getFuelLevel());
            vehicle.stop();
            System.out.println();
        }
    }
}
